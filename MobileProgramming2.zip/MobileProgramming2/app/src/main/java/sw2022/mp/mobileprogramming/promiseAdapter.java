package sw2022.mp.mobileprogramming;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class promiseAdapter  extends BaseAdapter {
    Context mContext = null;
    LayoutInflater mLayoutInflater = null;
    ArrayList<PromiseData> sample;

    public promiseAdapter(Context context, ArrayList<PromiseData> data) {
        mContext = context;
        sample = data;
        mLayoutInflater = LayoutInflater.from(mContext);
    }
    @Override
    public int getCount() {
        return sample.size();
    }

    @Override
    public Object getItem(int i) {
        return sample.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int position, View converView, ViewGroup parent) {
        View view = mLayoutInflater.inflate(R.layout.promise_list_layout, null);

        ImageView imageView = (ImageView)view.findViewById(R.id.promise_imageNum);
        TextView promiseDate = (TextView)view.findViewById(R.id.checkpromise);
        TextView mfriendId = (TextView)view.findViewById(R.id.friendId);

        imageView.setImageResource(sample.get(position).getImageNum());
        promiseDate.setText(sample.get(position).getPromiseDate());

        return view;
    }
}
