package sw2022.mp.mobileprogramming;

public class FriendData {

    private int imageNum;
    private String friendName;
    private String friendEmailId;
    private String friendIdToken;

    public FriendData(){ }

    public FriendData(int imageNum, String friendName, String friendEmailId) {
        this.imageNum = imageNum;
        this.friendName = friendName;
        this.friendEmailId = friendEmailId;
    }

    public int getImageNum() {
        return imageNum;
    }

    public String getFriendName() {
        return friendName;
    }

    public void setFriendName(String friendName) {
        this.friendName = friendName;
    }

    public String getFriendEmailId() {
        return friendEmailId;
    }

    public void setFriendEmailId(String friendEmailId) {
        this.friendEmailId = friendEmailId;
    }

    public void setFriendIdToken(String friendIdToken) {
        this.friendIdToken = friendIdToken;
    }

    public String getFriendIdToken() { return friendIdToken; }
}